<?php
include 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
  <style>
    /* CSS styles for the student admission offers section */
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
      margin: 0;
      padding: 0;
    }
    
    .admission-offers {
      background-color: #fff;
      max-width: 800px;
      margin: 40px auto;
      padding: 40px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    .admission-offers h2 {
      font-size: 28px;
      margin-top: 0;
      color: #333;
    }
    
    .offer-item {
      margin-bottom: 30px;
    }
    
    .offer-item h3 {
      font-size: 24px;
      margin-top: 0;
      color: #333;
    }
    
    .offer-item p {
      margin: 0;
      color: #666;
      line-height: 1.5;
    }
    
    .discount {
      color: #f44336;
      font-weight: bold;
    }
    
    .highlight {
      background-color: #f5f5f5;
      padding: 10px;
      border-radius: 4px;
    }
  </style>
</head>
<body>
  <div class="admission-offers">
    <h2>Student Admission Offers and Discounts</h2>
    
    <div class="offer-item">
      <h3>Early Bird Discount</h3>
      <p>Enroll before <span class="discount">June 30th</span> and get a <span class="discount">10% discount</span> .</p>
      <p class="highlight">Limited seats available! Secure your spot now.</p>
    </div>
    
    <div class="offer-item">
      <h3>Sibling Discount</h3>
      <p>Receive a <span class="discount">15% discount</span> on tuition fees for each additional sibling enrolled.</p>
      <p class="highlight">Take advantage of our special discount for families with multiple children.</p>
    </div>
    
    <div class="offer-item">
      <h3>Academic Excellence Scholarship</h3>
      <p>Merit-based scholarship available for students with outstanding academic achievements.</p>
      <p class="highlight">Apply now to be considered for this prestigious scholarship.</p>
    </div>
    
    <div class="offer-item">
      <h3>Financial Aid Program</h3>
      <p>Financial assistance available for eligible students based on need and circumstances.</p>
      <p class="highlight">Contact us to learn more about our financial aid program.</p>
    </div>
    
    <div class="offer-item">
      <h3>Sports Achievement Discount</h3>
      <p>Special discount available for students with exceptional sports achievements.</p>
      <p class="highlight">Showcase your sports skills and avail of this exclusive discount.</p>
    </div>
  </div>
</body>
</html>

