<?php
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>Student Admission Management System</title>
    <style>
        body {
            background-image: url(images/bg2.jpg);
            background-repeat: no-repeat;
            background-size: cover;
            height: 100vh;
            background-position: center;
        }
        .container-home{
            margin-top: 350px;
        }
        .container-home h2{
            margin-right: 50px;
        }

    </style>
</head>

<body>
    <center>
        <div class="container-home">
            <h2 style="margin-right:200px; color:blue;">Your Path to Greatness Starts Here: Join Us and Excel!
            </h2>
            <a href="login.php" class="btn btn-primary fs-4">Get Started</a>
        </div>
    </center>
</body>

</html>