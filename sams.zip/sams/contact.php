<?php
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <header>
        <title>Admisssion</title>
        <link rel="stylesheet" href="css/login.css">


    </header>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Poppins:wght@200;300;400&display=swap" rel="stylesheet">

<style>



h1 {
  text-align: center;
}

form {
  width: 400px;
  margin: 0 auto;
}

label {
  display: block;
  margin-top: 10px;
}

input[type="text"],
input[type="email"],
input[type="tel"],
textarea {
  width: 100%;
  padding: 5px;
  margin-top: 5px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

input[type="submit"] {
  display: block;
  width: 100%;
  padding: 10px;
  margin-top: 10px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type="submit"]:hover {
  background-color: #45a049;
}

</style>
</head>
<?php
include 'dbconnect.php';


//get form data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone=$_POST['phone'];
  $subject = $_POST['subject'];
  $message=$_POST['message'];



  $sql_check = "SELECT * FROM student WHERE email = '$email'";
  $result_check = mysqli_query($con, $sql_check);

  if (mysqli_num_rows($result_check) > 0) {
    echo "Email already exists!";
  } else {
    // Create SQL INSERT statement
    $sql = "INSERT INTO contact(name,email, phone,subject,message) VALUES ('$name', '$email', '$phone','$subject', '$message')";

    // Execute the SQL statement
    if (mysqli_query($con, $sql)) {
      echo "New record created successfully";
      header('location:login.php');
    } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($con);
    }
  }
}
?>
<body>
 
  
  <!DOCTYPE html>
<html>
<head>
  <title>Contact Us</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <h1>Contact Us</h1>
  <form action="contact.php" method="POST"  onsubmit="return validateForm()">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" required>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>

    <label for="phone">Phone number:</label>
    <input type="tel" id="phone" name="phone">

    <label for="subject">Subject:</label>
    <input type="text" id="subject" name="subject" required>

    <label for="message">Message:</label>
    <textarea id="message" name="message" required></textarea>

    <input type="submit" value="Submit">
  </form>
  
 

<script>
function validateForm() {
  var name = document.getElementById("name").value;
  var email = document.getElementById("email").value;
  var phone = document.getElementById("phone").value;
  var subject = document.getElementById("subject").value;
  var message = document.getElementById("message").value;

  // Check for empty fields
  if (name.trim() === "" || email.trim() === "" || subject.trim() === "" || message.trim() === "") {
    alert("Please fill in all required fields.");
    return false;
  }

  // Check email format
  if (!isValidEmail(email)) {
    alert("Please enter a valid email address.");
    return false;
  }

  // Check phone number format
  if (phone.trim() !== "" && !isValidPhoneNumber(phone)) {
    alert("Please enter a valid phone number.");
    return false;
  }

  return true;
}

function isValidEmail(email) {
  // Regular expression to validate email format
  var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhoneNumber(phone) {
  // Regular expression to validate phone number format
  var phoneRegex = /^\d{10}$/;
  return phoneRegex.test(phone);
}
</script>







</body>
</html>

