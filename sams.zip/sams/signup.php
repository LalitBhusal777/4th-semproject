<?php
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <title>Admisssion</title>
  <link rel="stylesheet" href="css/login.css">


</head>
<?php
include 'dbconnect.php';


//get form data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $age=$_POST['age'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $confirm_password=$_POST['confirm_password'];
  $checkbox = $_POST['checkbox'];


  $sql_check = "SELECT * FROM student WHERE email = '$email'";
  $result_check = mysqli_query($con, $sql_check);

  if (mysqli_num_rows($result_check) > 0) {
    echo "Email already exists!";
  } else {
    // Create SQL INSERT statement
    $sql = "INSERT INTO student(firstname,lastname,age,email, password,confirm_password) VALUES ('$firstname', '$lastname', '$age','$email', '$password', '$confirm_password')";

    // Execute the SQL statement
    if (mysqli_query($con, $sql)) {
      echo "New record created successfully";
      $_SESSION['email']='$email';
      $_SESSION['pass']='$password';
      header('location:login.php');
    } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($con);
    }
  }
}
?>

<body>


  <div class="reg">
  <form action="" method="post" onsubmit="return validateForm()">
  <h2 class="regi">Register</h2>
  <label for="Firstname">First Name</label>
  <input type="text" id="Firstname" name="firstname" placeholder="Enter Firstname" required>

  <label for="Lastname">Last Name</label>
  <input type="text" id="Lastname" name="lastname" placeholder="Enter Lastname" required><br>

  <label for="Age">Age</label>
  <input type="text" id="Age" name="age" placeholder="Enter your age" required><br>

  <label for="Email">Email</label>
  <input type="text" id="Email" name="email" placeholder="Enter your email" required><br>

  <label for="password">Password</label>
  <input type="password" id="password" name="password" placeholder="Password" required><br>

  <label for="confirm_password">Confirm password</label>
  <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm password" required>

  <p><input type="checkbox" name="checkbox" required> I agree with <strong>terms and conditions</strong> and the <strong>privacy policy</strong></p><br>
  <button type="submit">Register</button>
</form>

<script>
function validateForm() {
    var firstname = document.getElementById("Firstname").value.trim();
    var lastname = document.getElementById("Lastname").value.trim();
    var age = document.getElementById("Age").value.trim();
    var email = document.getElementById("Email").value.trim();
    var password = document.getElementById("password").value;
    var confirm_password = document.getElementById("confirm_password").value;

    if (firstname === "" || lastname === "" || age === "" || email === "" || password === "" || confirm_password === "") {
      alert("All fields are required!");
      return false;
    }

    if (password !== confirm_password) {
      alert("Passwords do not match!");
      return false;
    }

    if (password.length < 8) {
      alert("Password must be at least 8 characters long!");
      return false;
    }

    // Validate email format
    var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,})+$/;
    if (!email.match(emailRegex)) {
      alert("Invalid email address!");
      return false;
    }

    // Validate age
    var ageValue = parseInt(age);
    if (isNaN(ageValue) || ageValue <= 0 || ageValue >= 150) {
      alert("Invalid age!");
      return false;
    }

    // Add more validation checks if needed

    return true; // Submit the form if all validations pass
  }
</script>


  </div>
  <footer>
    <p class="cop">Copyright &copy;2023</p>
  </footer>
</body>

</html>

<?php

function sendEmail($recipientEmail, $subject, $message) {


    $senderEmail = 'lalitbhusal165@gmail.com';


    $headers = "From: $senderEmail\r\n";
    $headers .= "Reply-To: $senderEmail\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=utf-8\r\n";

    try {
        if (mail($recipientEmail, $subject, $message, $headers, "-f $senderEmail")) {
            echo "Email sent successfully!";
        } else {
            echo "Failed to send the email.";
        }
    } catch (Exception $e) {
        echo "An error occurred while sending the email: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$firstname=$_POST['firstname'];
 
    

    $subject = 'Account Created Successfuly!';
    $message = "Dear $firstname  You have created an account successfully on student admission management system, Now you can login and admission the students from online easily!";

    sendEmail($email, $subject, $message);
}
?>