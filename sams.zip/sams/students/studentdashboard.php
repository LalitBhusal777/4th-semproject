<?php
include '../dbconnect.php';

session_start();

// Check if the user is not logged in
if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    // Redirect to the login page
    header('Location:../login.php');
    exit();
}

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Retrieve form data
    $studentName = $_POST['student_name'];
    $parentsName = $_POST['parents_name'];
    $contact = $_POST['contact'];
    $age = $_POST['age'];
    $dob = $_POST['date_of_birth'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $class = $_POST['class'];

    // Check if the email already exists
    $query = "SELECT COUNT(*) FROM admission_form WHERE email = '$email'";
    $result = mysqli_query($con, $query);
    $count = mysqli_fetch_row($result)[0];

    if ($count > 0) {
        // Email already exists, handle it accordingly (e.g., display an error message)
        echo "Email already exists!";
    } else {
        // Insert the new record into the table
        $insertQuery = "INSERT INTO admission_form (student_name, parents_name, contact, age, date_of_birth,  email, gender, class) 
                        VALUES ('$studentName', '$parentsName', '$contact', '$age', '$dob', '$email', '$gender', '$class')";

        // Run the query
        if (mysqli_query($con, $insertQuery)) {
            // Data inserted successfully
            echo "Data inserted into the database.";
        } else {
            // Error in insertion
            echo "Error: " . mysqli_error($con);
        }
    }

    // Close the database connection
    mysqli_close($con);
}
?>

<!-- Rest of the HTML and JavaScript code remains the same -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
       body {
            font-family: Arial, sans-serif;
        }

       
          
        

        .main-container {
            margin: 20px;
        }

        form {
            width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f1f1f1;
            border-radius: 5px;
        }

        form label {
            display: block;
            font-weight: bold;
            margin-top: 10px;
        }

        form input[type="text"],
        form select 
            {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
           
            }
            form input[type="date"] {
                width: 100%;
            padding: 5px;
            margin-bottom: 10px;
           
            }
      
        

        form input[type="radio"] {
            margin-right: 10px;
        }

        form .sub {
            display: block;
            width: 100%;
            padding: 10px 20px;
            background-color: #0000ff;
            color: #fff;
            border: none;
            cursor: pointer;
        }
       
        .navbar {
        background-color: #333;
        overflow: hidden;
        margin: auto;
        padding: auto;
    }

    /* Style for the navigation bar links */
    .navbar a {
        float: left;
        color: #f2f2f2;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        font-size: 17px;
    }

    /* Style for the active link */
    .navbar a.active {
        background-color: #4CAF50;
      
    }

   


    </style>
</head>
<body>
    <div class="navbar">
        <a class="active" href="studentdashboard.php">Student Admission Form</a>
    </div>

    <div class="main-container">
        <form action="studentdashboard.php" method="POST" onsubmit="return validateForm()">
            <label>Student name</label>
            <input type="text" name="student_name" placeholder="Enter student full name"><br>

            <label>Parents name</label>
            <input type="text" name="parents_name" placeholder="Enter parents name"><br>

            <label>Contact</label>
            <input type="text" name="contact" placeholder="Enter contact number"><br>

            <label>Age</label>
            <input type="text" name="age" placeholder="Enter your age"><br>

            <label for="date-of_birth">Date of Birth</label>
            <input type="date" id="date_of_birth" name="date_of_birth" placeholder="year/mm/dd"><br>

           

            <label>Email</label>
            <input type="text" name="email" placeholder="Enter your mail"><br>

            <p>Gender:</p>
            <label for="male">Male</label>
            <input type="radio" id="male" name="gender" value="male">
            <label for="female">Female</label>
            <input type="radio" id="female" name="gender" value="female">
            <label for="other">Other</label>
            <input type="radio" id="other" name="gender" value="other">
          

            <label for="class">Class:</label>
            <select id="class" name="class" required>
                <option value="">--Select--</option>
                <option value="Play Group">Play Group</option>
                <option value="Lkg">Lkg</option>
                <option value="Ukg">Ukg</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>
            <br><br>
           

            <input type="submit" value="Submit" class="sub" name="submit">
        </form>
    </div>
    <script>
      function validateForm() {
    var studentName = document.getElementsByName('student_name')[0].value;
    var parentsName = document.getElementsByName('parents_name')[0].value;
    var contact = document.getElementsByName('contact')[0].value;
    var age = document.getElementsByName('age')[0].value;
    var dateOfBirth = document.getElementsByName('date_of_birth')[0].value;
    var email = document.getElementsByName('email')[0].value;

    // Validate student name (only alphabets and spaces allowed)
    var nameRegex = /^[A-Za-z\s]+$/;
    if (!nameRegex.test(studentName)) {
      alert("Please enter a valid student name");
      return false;
    }

    // Validate parents name (only alphabets and spaces allowed)
    if (!nameRegex.test(parentsName)) {
      alert("Please enter a valid parents name");
      return false;
    }

    // Validate contact number (10 digits required)
    var contactRegex = /^\d{10}$/;
    if (!contactRegex.test(contact)) {
      alert("Please enter a valid 10-digit contact number");
      return false;
    }

    // Validate age (should be a positive number)
    var ageValue = parseInt(age);
    if (isNaN(ageValue) || ageValue <= 0) {
      alert("Please enter a valid age (a positive number)");
      return false;
    }

    // Validate email address
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      alert("Please enter a valid email address");
      return false;
    }

    // Validation successful
    return true;
  }


             
</script>
</body>
</html>
<?php

function sendEmail($recipientEmail, $subject, $message) {


    $senderEmail = 'lalitbhusal165@gmail.com';


    $headers = "From: $senderEmail\r\n";
    $headers .= "Reply-To: $senderEmail\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=utf-8\r\n";

    try {
        if (mail($recipientEmail, $subject, $message, $headers, "-f $senderEmail")) {
            echo "Email sent successfully!";
        } else {
            echo "Failed to send the email.";
        }
    } catch (Exception $e) {
        echo "An error occurred while sending the email: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$studentname=$_POST['studentname'];
 
    

    $subject = 'Form submitted sussessfully!';
    $message = "Dear $studentname  You have submitted the form successfully on student admission management system, Now you can visit the school for more detail...!";

    sendEmail($email, $subject, $message);
}
?>



