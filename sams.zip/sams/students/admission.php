<?php
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <header>
        <title>Admisssion</title>
        <style>
     
        </style>
    </header>
   
</head>
<body>

    <link rel="stylesheet" href="css/login.css">
   

      <div class="main-container">
        
      <form>
        <h2 class="std">Student admission form</h2>
        <label>Student name</label>
        <input type="text" Name="Name" placeholder="Enter student full name"><br>
        <label>Parents name</label>
        <input type="text" Name="Name" placeholder="Enter parents name"><br>
        <label>contact</label>
        <input type="text" Name="contact" placeholder="Enter contact number"><br>
        <label>age</label>
        <input type="text" Name="age" placeholder="Enter your age"><br>
        <label for="dob">Date of Birth</label><br>
<input type="date" id="dob" name="dob"><br><br>

        <label>Blood group</label>
        <input type="text" Name="Blood group" placeholder="Enter your Blood group"><br>
       
        <label>Email</label>
        <input type="text" Name="Email" placeholder="Enter your mail"><br>
        <label for="Gender">Gender</label>
  <input type="radio" id="male" name="male" value="male">Male
  
 
  <input type="radio" id="female" name="female" value="female">Female<br><br>
        <label for="class">class:</label>
		<select id="class" name="class" required>
			<option value="" >--Select--</option>
			<option value="Play Group">Play Group</option>
			<option value="Lkg">Lkg</option>
			<option value="Ukg">Ukg</option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6">6</option>
			<option value="7">7</option>
			<option value="8">8</option>
			<option value="9">9</option>
			<option value="10">10</option>
			
		</select>
		<br><br>
        <label for="Termsandcondition">Terms and condition:</label>
        <br>
		<input type="checkbox" >
    <label for="Termsandcondition" style=" color:blue; font-size:14px; font-weight:bold;">The information which student provided for registration should be valid.</label>
		<br><br>
		<input type="submit" value="Submit" class="sub"><br><br>
    

      </form>
      </div>
      <footer>
        <p class="cop">Copyright @copy;2023</p>
      </footer>
</body>
</html>