<?php 
$server="localhost";
?>