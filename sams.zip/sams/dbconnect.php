<?php
$server="localhost";
$username="root";
$password="";
$database="sams";

$con= mysqli_connect($server,$username,$password,$database);
// check connection
if(!$con)
{
    echo"connection unsuccessfull";
}
?>


