<?php
include '../dbconnect.php';

// Get form data
if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $sql = "SELECT * FROM admission_form WHERE fid=$id";
  $result = mysqli_query($con, $sql);
  $row = mysqli_fetch_assoc($result);

  $fid = $row['fid'];
  $student_name = $row['student_name'];
  $parents_name = $row['parents_name'];
  $contact = $row['contact'];
  $age = $row['age'];
  $date_of_birth = $row['date_of_birth'];
  $email = $row['email'];
  $gender = $row['gender'];
  $class = $row['class'];
}
?>
<html>
<head>
  <title>Student Admission Management System</title>
  <script src="https://kit.fontawesome.com/be7d3971df.js" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/be7d3971df.js" crossorigin="anonymous"></script>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
  <style>
    * {
      font-family: poppins;
    }

    a:hover {
      text-decoration: none;
    }
    body {
      font-family: Arial, sans-serif;
    }

    .main-container {
      margin: 20px;
    }

    form {
      width: 400px;
      margin: 0 auto;
      padding: 20px;
      background-color: #f1f1f1;
      border-radius: 5px;
    }

    form label {
      display: block;
      font-weight: bold;
      margin-top: 10px;
    }

    form input[type="text"],
    [type="date"] form select {
      width: 100%;
      padding: 5px;
      margin-bottom: 10px;
    }

    form input[type="radio"] {
      margin-right: 5px;
    }

    form .sub {
      display: block;
      width: 100%;
      padding: 10px 20px;
      background-color: #0000ff;
      color: #fff;
      border: none;
      cursor: pointer;
    }

    .navbar {
      background-color: #333;
      overflow: hidden;
      margin: auto;
      padding: auto;
    }

    /* Style for the navigation bar links */
    .navbar a {
      float: left;
      color: #f2f2f2;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 17px;
    }

    /* Style for the active link */
    .navbar a.active {
      background-color: #4CAF50;
    }
  </style>
</head>

<body>

  <?php include('sidebar.php') ?>

  <div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="../inc/nav.php">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Edit Admission Form</li>
    </ol>
    <div class="card mb-3">
      <div class="main-container">
        <form action="" method="POST" onsubmit="return validateForm()">
          <label>Student name</label>
          <input type="text" name="student_name" placeholder="Enter student full name" value="<?php echo htmlspecialchars($student_name); ?>"><br>

          <label>Parents name</label>
          <input type="text" name="parents_name" placeholder="Enter parents name" value="<?php echo htmlspecialchars($parents_name); ?>"><br>

          <label>Contact</label>
          <input type="text" name="contact" placeholder="Enter contact number" value="<?php echo htmlspecialchars($contact); ?>"><br>
          <label>Age</label>
          <input type="text" name="age" placeholder="Enter your age" value="<?php echo htmlspecialchars($age); ?>"><br>


          <label>Date of Birth</label>
          <input type="date" name="date_of_birth" placeholder="Enter date of birth (yyyy/mm/dd)" value="<?php echo htmlspecialchars($date_of_birth); ?>"><br>



          <label>Email</label>
          <input type="text" name="email" placeholder="Enter your email" value="<?php echo htmlspecialchars($email); ?>"><br>

          <p>Gender:</p>
          <label for="male">Male</label>
          <input type="radio" id="male" name="gender" value="male" <?php if ($gender === 'male') echo 'checked'; ?>>
          <label for="female">Female</label>
          <input type="radio" id="female" name="gender" value="female" <?php if ($gender === 'female') echo 'checked'; ?>>
          <label for="other">Other</label>
          <input type="radio" id="other" name="gender" value="other" <?php if ($gender === 'other') echo 'checked'; ?>>


          <label for="class">Class:</label>
          <select id="class" name="class" required>
            <option value="">--Select--</option>
            <option value="Play Group" <?php if ($class === 'Play Group') echo 'selected'; ?>>Play Group</option>
            <option value="LKG" <?php if ($class === 'LKG') echo 'selected'; ?>>LKG</option>
            <option value="UKG" <?php if ($class === 'UKG') echo 'selected'; ?>>UKG</option>
            <?php
            for ($i = 1; $i <= 10; $i++) {
              echo '<option value="' . $i . '"';
              if ($class === strval($i)) echo ' selected';
              echo '>' . $i . '</option>';
            }
            ?>
          </select>
          <br><br>

          <input type="submit" value="Submit" class="sub" name="submit">

        </form>
      </div>
    </div>
  </div>
 
  </div>

  <script>
    function validateForm() {
      var studentName = document.getElementsByName('student_name')[0].value;
      var parentsName = document.getElementsByName('parents_name')[0].value;
      var contact = document.getElementsByName('contact')[0].value;
      var age = document.getElementsByName('age')[0].value;
      var dateOfBirth = document.getElementsByName('date_of_birth')[0].value;
      var email = document.getElementsByName('email')[0].value;

      // Validate student name (only alphabets and spaces allowed)
      var nameRegex = /^[A-Za-z\s]+$/;
      if (!nameRegex.test(studentName)) {
        alert("Please enter a valid student name");
        return false;
      }

      // Validate parents name (only alphabets and spaces allowed)
      if (!nameRegex.test(parentsName)) {
        alert("Please enter a valid parents name");
        return false;
      }

      // Validate contact number (10 digits required)
      var contactRegex = /^\d{10}$/;
      if (!contactRegex.test(contact)) {
        alert("Please enter a valid 10-digit contact number");
        return false;
      }

      // Validate age (should be a positive number)
      var ageValue = parseInt(age);
      if (isNaN(ageValue) || ageValue <= 0) {
        alert("Please enter a valid age (a positive number)");
        return false;
      }

      // Validate email address
      var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        alert("Please enter a valid email address");
        return false;
      }

      // Validation successful
      return true;
    }
  </script>
</body>
</html>
<?php


if (isset($_POST['submit'])) {
  $student_name = $_POST['student_name'];
  $parents_name = $_POST['parents_name'];
  $contact = $_POST['contact'];
  $age = $_POST['age'];
  $date_of_birth = $_POST['date_of_birth'];
  $email = $_POST['email'];
  $gender = $_POST['gender'];
  $class = $_POST['class'];

  // Create SQL UPDATE statement
  $sql = "UPDATE admission_form SET student_name='$student_name', parents_name='$parents_name', contact='$contact',age='$age', date_of_birth='$date_of_birth', email='$email', gender='$gender', class='$class' WHERE fid=$id";

  // Execute the SQL statement
  $result = mysqli_query($con, $sql);
  if ($result) {
    echo "Record updated successfully";
    header('Location: admin-managestudentform.php');
    exit();
  } else {
    die(mysqli_error($con));
  }
}
?>