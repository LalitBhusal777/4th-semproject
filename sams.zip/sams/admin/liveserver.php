<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "sams";

$con = mysqli_connect($server, $username, $password, $database);
// check connection
if (!$con) {
    echo "connection unsuccessfull";
}

if (isset($_POST['input'])) {
    $input = $_POST['input'];
    $qry = "SELECT * FROM admission_form WHERE class LIKE '$input%'";
    $result = mysqli_query($con, $qry);
}


?>

<div class="card-body">
    <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>Form id</th>
                <th>Student Name</th>
                <th>Parents Name</th>
                <th>Contact</th>
                <th>Age</th>
                <th>Date of birth</th>
                <th>Email</th>
                <th>Gender</th>
                <th>Class</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (isset($result) && mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
            ?>
                    <tr>
                        <td><?php echo $row['fid'] ?></td>
                        <td><?php echo $row['student_name'] ?></td>
                        <td><?php echo $row['parents_name'] ?></td>
                        <td><?php echo $row['contact'] ?></td>
                        <td><?php echo $row['age'] ?></td>
                        <td><?php echo $row['date_of_birth'] ?></td>
                        <td><?php echo $row['email'] ?></td>
                        <td><?php echo $row['gender'] ?></td>
                        <td><?php echo $row['class'] ?></td>
                    </tr>
            <?php
                }
            } else {
                echo "<tr><td colspan='9'>No records found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
      
	  
	  
	  
	  
	  


