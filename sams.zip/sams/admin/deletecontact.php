<?php
include '../dbconnect.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM contact WHERE cid = '$id'";
    $result = mysqli_query($con, $sql);

    if ($result) {
       header('location:admin-viewcontact.php');
    } else {
        echo "Error deleting student record: " . mysqli_error($con);
    }
} else {
    echo "student ID not specified";
}
?>
