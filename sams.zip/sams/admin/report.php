<?php
// Include your database connection code here
// Example:
// $conn = mysqli_connect("localhost", "username", "password", "database_name");

// Function to generate a report for a specific class
function generateClassReport($classId) {
    global $conn;

    $classId = mysqli_real_escape_string($conn, $classId);

    // Query to fetch students of a specific class
    $query = "SELECT * FROM students WHERE class_id = '$classId'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "<h2>Class Report for Class ID: $classId</h2>";
        echo "<table>
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Address</th>
                </tr>";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['student_id']}</td>
                    <td>{$row['student_name']}</td>
                    <td>{$row['age']}</td>
                    <td>{$row['address']}</td>
                </tr>";
        }

        echo "</table>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

// Usage example: generate report for Class ID 1
generateClassReport(1);

// Close the database connection
mysqli_close($conn);
?>
