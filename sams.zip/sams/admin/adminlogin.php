<?php

session_start();
include '../dbconnect.php';
include '../header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the "email" and "password" keys exist in the $_POST array
    if (isset($_POST['email']) && isset($_POST['password'])) {
        // Get the input values from the login form
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Query your database to check if the email and password match with the data stored for admin credentials
        $sql = "SELECT * FROM administrator WHERE email='$email' AND password='$password'";
        $result = mysqli_query($con, $sql);

        if (mysqli_num_rows($result) == 1) {
            // If the email and password match, set a session variable to indicate that the admin is logged in and redirect the admin to the admin dashboard
            $_SESSION['loggedIn'] = true;
            $_SESSION['email'] = $email;

            header("location: admindashboard.php");
            exit();
        }
    }
}
?>


<!DOCTYPE html>
<html>
<head>
  
  <title>Login Form</title>
  <link rel="stylesheet" type="text/css" href="styles.css">
  <style>
    body {
  background-color: #f1f1f1;
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
}

.login-container {
  background-color: #ffffff;
  border-radius: 5px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  max-width: 300px;
  margin: 100px auto;
  padding: 20px;
}

h1 {
  text-align: center;
}

form input {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

form button {
  width: 100%;
  padding: 10px;
  background-color: #4CAF50;
  color: #ffffff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

form button:hover {
  background-color: #45a049;
}

form input[type="text"]:focus,
form input[type="password"]:focus {
  outline: none;
  border: 1px solid #4CAF50;
}

  </style>
</head>
<body>
  <div class="login-container">
    <h1> Administrator Login</h1>
    <form method="post">
      <input type="email" placeholder="Email" name="email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>
  </div>
  ?>
</body>
</html>
