
<?php

$id=$_GET['id'];
include '../dbconnect.php';
$qry="UPDATE admission_form  set status='verified' where fid=$id";
if(mysqli_query($con,$qry))
{
    echo"admission successfully";
    header('location:admin-viewnewadmission.php');
}


?>