<html>

<head>
    <title>Student Admission Management System</title>
    <script src="https://kit.fontawesome.com/be7d3971df.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/be7d3971df.js" crossorigin="anonymous"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: poppins;
        }

        a:hover {
            text-decoration: none;
        }
    </style>
</head>

<body>

    <?php include('sidebar.php') ?>

    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="../inc/nav.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Booking</li>
        </ol>




        <div class="card mb-3">
            <div class="card-header">
                <i class="fas fa-table" style="padding: 10px;;"></i>
                Booking

            </div>
            <div class="card-body">
                <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">



                    <thead>
                        <tr>
                            <th>Form id</th>
                            <th>Student Name</th>
                            <th>parents Name</th>
                            <th>Contact</th>
                            <th>Age</th>
                            <th>Date of birth</th>
                            <th>Email</th>
                            <th>Gender</th>
                            <th>Class</th>

                        </tr>
                    </thead>
                    <?php
                    include '../dbconnect.php';



                    if (isset($_GET['id'])) {
                        $id = $_GET['id'];
                        $sql = "SELECT * FROM student_form WHERE fid=$id";
                        $result = mysqli_query($con, $sql);
                        $row = mysqli_fetch_assoc($result);


                        $sql = "SELECT * FROM student_form";
                        $result = mysqli_query($con, $sql);
                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                $fid = $row['fid'];
                                $studentName = $row['student_name'];
                                $parentsName = $row['parents_name'];
                                $contact = $row['contact'];
                                $age = $row['age'];
                                $dob = $row['date_of_birth'];
                                $email = $row['email'];
                                $gender = $row['gender'];
                                $class = $row['class'];






                                if (isset($_POST['submit'])) {
                                    $student_name = $_POST['student_name'];
                                    $parents_name = $_POST['parents_name'];
                                    $contact = $_POST['contact'];
                                    $age = $_POST['age'];
                                    $date_of_birth = $_POST['date_of_birth'];
                                    $email = $_POST['email'];
                                    $gender = $_POST['gender'];
                                    $class = $_POST['class'];






                                    $result = mysqli_query($con, $sql);
                                    if ($result) {
                                        echo "Record updated successfully";
                                        header('Location:verifiedstudentform.php');
                                        exit();
                                    } else {
                                        die(mysqli_error($con));
                                    }
                                }
                            }
                        }
                    }

                    ?>
                    </tr>




                    <tbody>


                        </tr>


                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer small text-muted">
        </div>
    </div>

    </div>
    </div>
</body>



</html>