<?php
include '../dbconnect.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <title>Admission</title>
  <link rel="stylesheet" href="css/login.css">
  <style>
    .reg {
  width: 400px;
  margin: 0 auto;
}

.regi {
  text-align: center;
  font-size: 24px;
  margin-bottom: 20px;
}

form {
  padding: 20px;
  border: 1px solid #ccc;
  background-color: #f4f4f4;
  border-radius: 5px;
}

label {
  display: block;
  font-weight: bold;
  margin-bottom: 5px;
}

input[type="text"],
input[type="password"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

input[type="checkbox"] {
  margin-bottom: 15px;
}

button[type="submit"] {
  background-color: #4CAF50;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
}

button[type="submit"]:hover {
  background-color: #45a049;
}

.error {
  color: red;
  font-size: 14px;
  margin-top: 5px;
}

.success {
  color: green;
  font-size: 14px;
  margin-top: 5px;
}

  </style
</head>
<?php
//get form data
$id = $_GET['id'];
$sql = "SELECT * FROM student WHERE sid=$id";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);
$sid = $row['sid'];
$firstname = $row['firstname'];
$lastname = $row['lastname'];
$age = $row['age'];
$email = $row['email'];
$password = $row['password'];
$confirm_password = $row['confirm_password'];

if (isset($_POST['submit'])) {
  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $age = $_POST['age'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $confirm_password = $_POST['confirm_password'];
  $checkbox = $_POST['checkbox'];

  // Create SQL UPDATE statement
  $sql = "UPDATE student SET firstname='$firstname', lastname='$lastname', age='$age', email='$email', password='$password', confirm_password='$confirm_password' WHERE sid=$id";

  // Execute the SQL statement
  $_result = mysqli_query($con, $sql);
  if ($_result) {
    echo "Record updated successfully";

    header('location: admin-manage-student.php');
    exit(); // Don't forget to exit after redirection
  } else {
    die(mysqli_error($con));
  }
}
?>


<body>
  <div class="reg">
    <form action="" method="post" onsubmit="return validateForm()">
      <h2 class="regi">Register</h2>
      <label for="Firstname">First Name</label>
      <input type="text" id="Firstname" name="firstname" placeholder="Enter Firstname" value="<?php echo $firstname; ?>" required>

      <label for="Lastname">Last Name</label>
      <input type="text" id="Lastname" name="lastname" placeholder="Enter Lastname" value="<?php echo $lastname; ?>" required><br>

      <label for="Age">Age</label>
      <input type="text" id="Age" name="age" placeholder="Enter your age" value="<?php echo $age; ?>" required><br>

      <label for="Email">Email</label>
      <input type="text" id="Email" name="email" placeholder="Enter your email" value="<?php echo $email; ?>" required><br>

      <label for="password">Password</label>
      <input type="password" id="password" name="password" placeholder="Password" value="<?php echo $password; ?>" required><br>

      <label for="confirm_password">Confirm password</label>
      <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm password" value="<?php echo $confirm_password; ?>" required>

      <p><input type="checkbox" required> I agree with <strong>terms and conditions</strong> and the <strong>privacy policy</strong></p><br>
      <button type="submit" name="submit">Register</button>
    </form>
  </div>

  <footer>
    <p class="cop">Copyright &copy; 2023</p>
  </footer>

  <script>
  function validateForm() {
    var firstname = document.getElementById("Firstname").value.trim();
    var lastname = document.getElementById("Lastname").value.trim();
    var age = document.getElementById("Age").value.trim();
    var email = document.getElementById("Email").value.trim();
    var password = document.getElementById("password").value;
    var confirm_password = document.getElementById("confirm_password").value;

    if (firstname === "" || lastname === "" || age === "" || email === "" || password === "" || confirm_password === "") {
      alert("All fields are required!");
      return false;
    }

    if (password !== confirm_password) {
      alert("Passwords do not match!");
      return false;
    }

    if (password.length < 8) {
      alert("Password must be at least 8 characters long!");
      return false;
    }

    // Validate email format
    var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,})+$/;
    if (!email.match(emailRegex)) {
      alert("Invalid email address!");
      return false;
    }

    // Validate age
    var ageValue = parseInt(age);
    if (isNaN(ageValue) || ageValue <= 0 || ageValue >= 150) {
      alert("Invalid age!");
      return false;
    }

    // Add more validation checks if needed

    return true; // Submit the form if all validations pass
  }
</script>

</body>

</html>
In the updated code, we use parseInt() to convert the age value into an integer. Then we check if it's a valid number (not NaN) and within a reasonable range (between 1 and 149). If the age is not a positive number or is outside the reasonable range, an error message will be shown, and the form submission will be blocked.

With these additional validation checks, the form is now more robust and user-friendly. However, as always, remember to implement server-side validation using PHP to ensure data integrity and security.








</html>
