<?php
include '../dbconnect.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>verified form</title>
</head>
<?php



// Get form data
if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $sql = "SELECT * FROM student_form WHERE fid=$id";
  $result = mysqli_query($con, $sql);
  $row = mysqli_fetch_assoc($result);

  $fid = $row['fid'];
  $student_name = $row['student_name'];
  $parents_name = $row['parents_name'];
  $contact = $row['contact'];
  $age = $row['age'];
  $date_of_birth = $row['date_of_birth'];
  $email = $row['email'];
  $gender = $row['gender'];
  $class = $row['class'];
}

if (isset($_POST['submit'])) {
  $student_name = $_POST['student_name'];
  $parents_name = $_POST['parents_name'];
  $contact = $_POST['contact'];
  $age = $_POST['age'];
  $date_of_birth = $_POST['date_of_birth'];
  $email = $_POST['email'];
  $gender = $_POST['gender'];
  $class = $_POST['class'];

  // Create SQL UPDATE statement
  $sql = "UPDATE student_form SET student_name='$student_name', parents_name='$parents_name', contact='$contact',age='$age', date_of_birth='$date_of_birth', email='$email', gender='$gender', class='$class' WHERE fid=$id";

  // Execute the SQL statement
  $result = mysqli_query($con, $sql);
  if ($result) {
    echo "Record updated successfully";
    header('Location: admin-managestudentform.php');
    exit();
  } else {
    die(mysqli_error($con));
  }
}
?>
<!-- Fetch data from the "student" table -->
$sql = "UPDATE student_form set status = 'verified' WHERE fid = $fid";
if(mysqli_query($conn,$sql))
{
echo '<script>
  alert("Student Added Sucessfully")
</script>';
echo "<script>
  window.location.href = 'admin-viewverifiedstudent.php'
</script>";

}
else{
echo '<script>
  alert("Error adding student")
</script>';
echo "<script>
  window.location.href = 'admin-viewverifiedstudent.php'
</script>";
}

<div class="card-body">
  <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">



    <thead>
      <tr>
        <th>Form id</th>
        <th>Student Name</th>
        <th>parents Name</th>
        <th>Contact</th>
        <th>Age</th>
        <th>Date of birth</th>
        <th>Email</th>
        <th>Gender</th>
        <th>Class</th>

      </tr>
    </thead>
    <?php
    include '../dbconnect.php';
    $sql = "SELECT * FROM student_form";
    $result = mysqli_query($con, $sql);
    if ($result) {
      while ($row = mysqli_fetch_assoc($result)) {
        $fid = $row['fid'];
        $studentName = $row['student_name'];
        $parentsName = $row['parents_name'];
        $contact = $row['contact'];
        $age = $row['age'];
        $dob = $row['date_of_birth'];
        $email = $row['email'];
        $gender = $row['gender'];
        $class = $row['class'];

        echo '<tr>
            
            <th>' . $fid . '.</th>
            <td>' . $studentName . '</td>
            <td>' . $parentsName . '</td>
            <td>' . $contact . '</td>
            <td>' . $age . '</td>
            <td>' . $dob . '</td> 
            <td>' . $email . '</td> 
            <td>' . $gender . '</td> 
            <td>' . $class . '</td> 
          </tr>';
      }
    }
    ?>
    </tr>




    <tbody>


      </tr>


    </tbody>
  </table>
</div>
</div>
<div class="card-footer small text-muted">
</div>
</div>

</div>
</div>

</html>