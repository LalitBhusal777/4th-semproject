-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2023 at 06:10 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sams`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `aid` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`aid`, `email`, `password`) VALUES
(1, 'lalitbhusal165@gmail.com', 'lalit555');

-- --------------------------------------------------------

--
-- Table structure for table `admission_form`
--

CREATE TABLE `admission_form` (
  `fid` int(11) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `parents_name` varchar(255) NOT NULL,
  `contact` int(11) NOT NULL,
  `age` int(11) NOT NULL,
  `date_of_birth` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'None'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admission_form`
--

INSERT INTO `admission_form` (`fid`, `student_name`, `parents_name`, `contact`, `age`, `date_of_birth`, `email`, `gender`, `class`, `status`) VALUES
(16, 'Arman Adhikari', 'Ashok Adhikari', 2147483647, 52, '2020-02-11', 'prabhatghimire77@gmail.com', 'male', '6', 'verified'),
(20, 'Lalit Bhusal', 'Laxmi Bhusaal', 2147483647, 21, '2002-03-17', 'lalit@gmail.com', 'male', '7', 'verified'),
(21, 'sscrvgrfgvr', 'fvrbvrvr', 2147483647, 21, '2020-06-16', 'aar@gmail.com', 'male', '7', 'None'),
(22, 'Arman Adhikari', 'Ashok Adhikari', 2147483647, 21, '2018-12-30', 'ashok@gmail.com', 'male', '6', 'None'),
(23, 'Manish', 'dev naran', 98456, 21, '2019-06-19', 'manish@gmail.com', 'male', '8', 'None'),
(24, 'Arman Adhikari', 'Laxmi Bhusal', 980000, 21, '2023-07-10', 'laxmi@gmail.com', 'male', '4', 'None'),
(25, 'Arman Adhikari', 'Laxmi Bhusal', 2147483647, -4, '2023-07-18', 'aarm@gmail.com', 'male', '8', 'None'),
(26, 'Arman Adhikari', 'Laxmi Bhusal', 2147483647, 98, '2023-07-11', 'laxm@gmail.com', 'male', '6', 'None');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `cid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`cid`, `name`, `email`, `phone`, `subject`, `message`) VALUES
(9, 'baibob', 'lalitbhusal1651@gmail.com', '9877777777', 'Admission', 'jhdtrzr'),
(10, 'Lalit Bhusal', 'lalitbhusal165@gmail.com', '9845086885', 'nothing', 'kjasxiaca'),
(11, 'Lalit Bhusal', 'lalitbhusal165@gmail.com', '9742863845', 'Admission process', 'good');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `sid` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `confirm_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`sid`, `firstname`, `lastname`, `age`, `email`, `password`, `confirm_password`) VALUES
(23, 'prabhat', 'ghimire', 22, 'prgh_bca2077@lict.edu.np', '987654321', '987654321'),
(24, 'Arman', 'Adhikari', 2, 'lalitbhusal165@gmail.com', '567', '567'),
(25, 'laxu', 'bhusal', 21, 'laxu@gmail.com', '5555', '5555'),
(26, 'Prabhat', 'Adhikari', 26, 'prg@gmail.com', '8888', '8888'),
(27, 'manis', 'Ghimire', 2, 'manish@gmail.com', '0', 'manish@123'),
(28, 'rudal', 'kunwar', 21, 'rudal@gmail.com', '0', 'rudal@12345'),
(29, 'kuns', 'kuns', 21, 'kuns@gmail.com', '12345678', '12345678');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `admission_form`
--
ALTER TABLE `admission_form`
  ADD PRIMARY KEY (`fid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`sid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator`
--
ALTER TABLE `administrator`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admission_form`
--
ALTER TABLE `admission_form`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
