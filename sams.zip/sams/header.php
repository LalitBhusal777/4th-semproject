<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&family=Montserrat&family=Poppins:wght@200;300;400&display=swap" rel="stylesheet">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Admission Management System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Lato;
        }

        .container-main {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: black;
            color: white;
        }

        nav {
            padding: 10px;
        }

        nav ul {
            display: flex;
            padding: 10px;
        }

        nav ul li {
            list-style: none;


        }

        nav ul li a {
            color: white;
            font-size: 22px;
            text-decoration: none;
            padding: 20px;

        }
    </style>
</head>

<body>
    <div class="container-main">
        <div class="logo">
            <h2 style="margin-left:5px">SAMS</h2>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="admissionoffer.php">Admission Offer</a></li>
                <li><a href="contact.php">Contact us</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="signup.php">Signup</a></li>
            </ul>
        </nav>
    </div>
</body>

</html>